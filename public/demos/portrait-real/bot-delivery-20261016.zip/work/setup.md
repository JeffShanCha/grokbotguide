# Stage 1 setup — 真实内容画像演示
- 账号：@0xlangeai（蓝哥AI，user id 1759530111534243840），仅读公开数据，内置 `x` 命名空间。
- 范围：2026-10-16 前 30 天（2026-09-16 至 2026-10-16 UTC）、原创公开帖（非转推/回复/纯引用），主题为 AI 工具/工作流，取 8–12 条。
- 交接文件：source.csv（摘要+链接，可交接）；work/raw-posts.json（原文，仅私下核对，不发布）；work/id-map.json；work/intake-report.json；work/log-stage1-3.md。
- 不发布：不发帖、不私信、不联系任何人、不用 git/PR/部署/云代理/定时任务。
