# Log stages 1–3
执行者：二丫头 (single bot, collector role)

## 输入（原样）
New task (stages 1-3 of a real-content portrait demo). Work dir: /workspace/gbg-portrait-real-20261016/ (create; do NOT touch /workspace/gbg-portrait-lab-20261016/). No posting, DMs, contacting anyone, git, PR, deploy, cloud agents, routines. Read only public data of @0xlangeai via built-in `x` namespace (get_users_by_username, get_users_posts with exclude=retweets,replies, tweet.fields created_at,lang,note_tweet,referenced_tweets, max 25-ish). Don't bypass limits; don't invent records.
Stage 1 setup: write work/setup.md ... Stage 2 live: pick 8-12 original posts ... Stage 3 intake: check duplicates, empty, author match, url/id match, date in window; spot-check 2-3 posts ... Also log for each stage ... in work/log-stage1-3.md.
（完整字段要求见本任务原文：source.csv 列 id,date,text,url,source_kind,collected_at；摘要≤60字、非原文；id-map；intake-report。）

## Stage 1 — 2026-10-16 20:18:51 CST
- 输出：work/setup.md。用户 id 取自本会话先前的 get_users_by_username 结果（1759530111534243840），本阶段未重复调用。
- 检查：目录新建；未触碰 gbg-portrait-lab-20261016。

## Stage 2 — 20:18:51 至 20:19:35 CST
- 调用：get_users_posts ×3（exclude retweets,replies；start_time 2026-09-16；第 1 页 max 25 返回 23 条，第 2 页 max 100 实返回 25 条，第 3 页 max 25 返回 25 条），共 73 条，覆盖 2026-10-13 至 2026-10-16。
- 筛选：只要无 referenced_tweets 的原创帖且话题为 AI 工具；排除引用帖、自回复串、生活/社群/汽车类。选出 10 条。
- 输出：source.csv（10 行）、work/raw-posts.json、work/id-map.json。
- 检查：摘要≤60 字、非原文子串（脚本断言通过）。

## Stage 3 — 20:19:35 至 20:19:50 CST
- 检查：重复、空值、作者、url/id、日期窗口、摘要——全部通过，issues=[]。
- 抽查：get_posts_by_ids 重取 p02/p04/p10，id、作者、created_at 一致，无引用。
- 输出：work/intake-report.json。
- 局限：未读 2026-09-16 至 2026-10-13 的帖子，不代表收全；图片未看。
